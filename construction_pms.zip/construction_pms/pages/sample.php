<form action="../forms/update_forms.php?action=position" method="POST">
<input type="text" name="id" value="1"><br>
<input type="text" name="name"><br>
<input type="text" name="dr"><br>
<input type="submit" value="Submit">
</form>
