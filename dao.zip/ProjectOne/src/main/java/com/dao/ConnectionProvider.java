package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionProvider {

	private static Connection con=null;
	public static Connection getConnection()
	{
		try 
		{
			String url="jdbc:mysql://localhost:3306/";
			String db="amandb";
			String uname="root";
			String pass="1234";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection(url+db,uname,pass);
			System.out.println("Connection Succesfull");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
	}
}
