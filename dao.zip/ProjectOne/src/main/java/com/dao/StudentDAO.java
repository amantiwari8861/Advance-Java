package com.dao;

import com.entity.Student;

public interface StudentDAO 
{
	int saveData(Student s);
}
