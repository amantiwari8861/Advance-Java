package com.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.dao.ConnectionProvider;
import com.dao.StudentDAO;
import com.entity.Student;

public class StuDaoImplementation implements StudentDAO {
	private Connection con = null;

	@Override
	public int saveData(Student s) {
		int status = 0;
		try {
			con = ConnectionProvider.getConnection();

			PreparedStatement ps = con.prepareStatement("insert into emp(fname,lname,email,password) values(?,?,?,?);");
			ps.setString(1, s.getFname());
			ps.setString(2, s.getLname());
			ps.setString(3, s.getEmail());
			ps.setString(4, s.getPassword());
			status = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return status;
	}

}
