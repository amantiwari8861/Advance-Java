package com.Servlet;

public class UserServlet {

	public UserServlet() {
		// TODO Auto-generated constructor stub
	}

}
