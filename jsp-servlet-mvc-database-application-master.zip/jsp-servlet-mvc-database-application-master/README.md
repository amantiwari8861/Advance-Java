# jsp-servlet-mvc-database-application
Java MVC Web Application using JSP and Servlet

https://www.javaguides.net/2019/08/model-view-controller-mvc-design-in-java.html
